
public class Car implements Cloneable{

	private String color;
	private String manufacture;
	private Engine engine;
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getManufacture() {
		return manufacture;
	}
	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
	}
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	public Car(String color, String manufacture, Engine engine) {
		super();
		this.color = color;
		this.manufacture = manufacture;
		this.engine = engine;
	}
	public Car() {
		super();
	}
	
	
	
	@Override
	public String toString() {
		return "color: " + color + "\nmanufacture: " + manufacture + "\nengine: " + engine;
		
	}
	public Object Clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	
	public static void main(String[]args)
	{
		try {
			Engine e1 = new Engine(120.2);
			Car c1 = new Car("black","Nissan",e1);
			Car c2 = (Car)c1.Clone();
			
			System.out.println(c1);
			System.out.println(c2);
			
			c2.setEngine(new Engine(833.83));
			
			System.out.println(c1);
			System.out.println(c2);
			
			}catch(CloneNotSupportedException e)
		{
			System.out.println(e);
		}
	}
}
