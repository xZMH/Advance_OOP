
public class Engine {

	private double horsepower;

	public double getHorsepower() {
		return horsepower;
	}

	public void setHorsepower(double horsepower) {
		this.horsepower = horsepower;
	}

	public Engine() {
		super();
	}

	public Engine(double horsepower) {
		super();
		this.horsepower = horsepower;
	}
	
	public String toString()
	{
		return "HorsePower :" + this.horsepower+"\n\n";
	}
}
